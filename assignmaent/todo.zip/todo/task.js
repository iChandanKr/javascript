export const todoList = [
    {
      id: 1,
      title: "Buy groceries",
      description: "Milk, eggs, bread, and coffee",
      isCompleted: false,
      favourite: true,
    },
    {
      id: 2,
      title: "Complete project report",
      description: "Finalize the report and send it to the team",
      isCompleted: false,
      favourite: false,
    },
    {
      id: 3,
      title: "Call the doctor",
      description: "Schedule an appointment for a routine check-up",
      isCompleted: false,
      favourite: false,
    },
    {
      id: 4,
      title: "Read a book",
      description: "Finish reading 'The Great Gatsby'",
      isCompleted: false,
      favourite: true,
    },
  ];
  